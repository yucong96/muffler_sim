#!/bin/bash

#PROJECT_PATH=/home/jchen/Documents/project/project_test/docker-muffler/docker/
PROJECT_PATH=/

APP_PATH=${PROJECT_PATH}app
CONFIG_PATH=${PROJECT_PATH}config
DATA_PATH=${PROJECT_PATH}data
OUTPUT_PATH=${PROJECT_PATH}output

chmod 777 ${APP_PATH}/bin/geo_gen
chmod 777 ${APP_PATH}/bin/vol2vtk
chmod 777 ${APP_PATH}/bin/muffler

cd ${CONFIG_PATH}
ls=`ls`
MODEL_NAME=$(basename ${ls} .txt)

cd ${APP_PATH}
mkdir -p ${APP_PATH}/geo
mkdir -p ${APP_PATH}/vol
GEO_CONFIG_PATH=${CONFIG_PATH}/${MODEL_NAME}.txt
GEO_PATH=${APP_PATH}/geo/${MODEL_NAME}.geo
VOL_PATH=${APP_PATH}/vol/${MODEL_NAME}.vol
VTK_PATH=${DATA_PATH}/${MODEL_NAME}.vtk

./bin/geo_gen ${GEO_CONFIG_PATH} ${GEO_PATH}
netgen -geofile=${GEO_PATH} -meshfile=${VOL_PATH} -batchmode
./bin/vol2vtk ${VOL_PATH} ${VTK_PATH}

./bin/muffler ${CONFIG_PATH}/${MODEL_NAME} ${DATA_PATH}/${MODEL_NAME} ${OUTPUT_PATH}/${MODEL_NAME}
